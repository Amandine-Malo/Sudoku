#include <stdlib.h>
#include <uvsqgraphics.h>
#include "constantes.h"
#include "gestion_sudoku.h"
#include "afficher.h"

SUDOKU undo(SUDOKU S){
	ACTION *a;
	if(S.jeu == NULL){
		affiche_message("Plus de retour en arri"egrave"re possible");
		return S;
	}
	int ligne = S.jeu->l;
	int colonne = S.jeu->c;
	S.T[ligne][colonne].val = S.jeu->a;	//Remet ancienne valeur
	S = sudoku_afficher(S); 			//Affiche ancienne valeur
	affiche_message("Retour en arri"egrave"re r"eacute"alis"eacute"");
	a = S.jeu;			//Sauvegarde l'action en court
	S.jeu = a->prec;	//action en court = action précédente
	free(a);			//libère la mémoire
	return S;
}

int val_utilise_h(SUDOKU S,int l,int c,int v){
	for(int i=0;i<VALEUR;i++)
		if((i != c) && (S.T[l][i].val == v)) return 1;	//Ne prends pas en compte la valeur sur laquelle on est
	return 0;	//renvois valeur non utilisée
}

int val_utilise_v(SUDOKU S,int l,int c,int v){
	for(int i=0;i<VALEUR;i++)
		if((i != l) && (S.T[i][c].val == v)) return 1;
	return 0;
}

int val_utilise_c(SUDOKU S, int l, int c, int v){
	int i,j,a,b;
	for(i=0;i<VALEUR/3;i++){		//Parcours les 3 valeurs des lignes de la case
		for(j=0;j<VALEUR/3;j++){		//Parcours les 3 valeurs des colonnes de la case
			a = (l/3)*3 +i;
			b = (c/3)*3 +j;
			if((a!=l) && (b!=c) && (S.T[a][b].val == v)) return 1;
		}
	}
	return 0;
}

int val_utilise(SUDOKU S, int l, int c, int v){
	if(val_utilise_h(S,l,c,v)) return 1;
	if(val_utilise_v(S,l,c,v)) return 1;
	if(val_utilise_c(S,l,c,v)) return 1;
	return 0;
}

int val_possible(SUDOKU S, int l, int c, int v){
	if(v==9) return 0;
	if(!(val_utilise(S,l,c,v+1))) return v+1;		//Si v+1 non utilisée, renvoie v+1
		else return val_possible(S,l,c,v+1);
}

SUDOKU sudoku_modifier_case(SUDOKU S, int l, int c){
	int v = S.T[l][c].val;
	int r;
	ACTION *a;	//Déclare pointeur, a renvoie l'adresse
	
	a = malloc(sizeof(ACTION));	//Allocation mémoire pour la nouvelle action
	a->l = l;					//Sauvegarde des valeurs de l'action en cours
	a->c = c;
	a->a = v;
	
	r = val_possible(S,l,c,v);	//Recherche de la prochaine valeur possible
	S.T[l][c].val = r;
	S = sudoku_afficher(S);
	a->prec = S.jeu;	//Empilage des valeurs
	S.jeu = a;			//Màj dernière action faite
	
	return S;
}

SUDOKU resolution(SUDOKU S, int val){
	int l,c,i;
	if(val == VALEUR*VALEUR){	// Si le sudoku est finis
		 S.quit = 1;
		 S = sudoku_afficher(S);
		 return S;
	 }
	 l = val/VALEUR;			// Cherche la ligne (val/VALEUR renvois la partie entière)
	 c = val-(VALEUR*l);		// Cherche la case sur la ligne (le reste est utilisé)
	 
	 if(S.T[l][c].val != 0){	// Si valeur != 0 on passse à la valeur suivante
		S = resolution(S,val+1);
		return S;
	}
	
	for(i=1;i<=VALEUR;i++){		// Si la case est vide : on teste toutes les valeurs pour la résolution
		if(val_utilise(S,l,c,i) == 0){
			S.T[l][c].val = i;
			S = resolution(S,val+1);
		}
	}
	S.T[l][c].val = 0;
	return S;
}
