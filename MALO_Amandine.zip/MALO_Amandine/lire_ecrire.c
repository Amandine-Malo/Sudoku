#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <uvsqgraphics.h>
#include "constantes.h"
#include "gestion_sudoku.h"

#define ASCII_0 48 //code Ascii de 0 pour passer de char à int

SUDOKU nom_fichier(SUDOKU S, char *nom){
	char v[50];
	//sscanf : lis chaine de caractère et la met dans des variables
	//%[^.] : lis tout sauf le point, s'arrête au premier point
	//.  : exclus le point
	int i = sscanf(nom,"%[^.].%[^.].%s",S.fichier,v,S.extension);
	if(i == 2){
								//strcpy : Copie une chaine de caractère dans une chaine de caractère
		strcpy(S.extension,v);	//Copie v dans extension
		strcpy(v,"0000");		//Copie les 0 dans v
	}
	S.version = atoi(v);	//char to int
	return S;
}

SUDOKU lire_fichier (char *nom) {
	int i,j,c;
	SUDOKU S;
	FILE *F = NULL;
	S = nom_fichier(S,nom);
	F = fopen(nom,"r");
	if(F==NULL) printf("Fichier vide");
	
	for(i=0;i<VALEUR && !feof(F);i++){
		for(j=0;j<VALEUR;j++){
			c = fgetc(F);
			
			if(c == '.'){
				c = 0;
				S.T[i][j].tra = 1;	//Variable de travail
			}
			else{
					if(c == '*'){
						c = fgetc(F);
						S.T[i][j].tra = 1;	//Variable de travail
					}
						else S.T[i][j].tra = 0;
					c = c - ASCII_0;	//Passe du code ASCII du caractère à un entier
				}
				
			S.T[i][j].val = c;	
			S.T[i][j].bg.x = (TAILLE_CASE*j) +1;
			S.T[i][j].bg.y = (HAUTEUR -(TAILLE_CASE*(i+1)))-1;
			S.T[i][j].hd.x = S.T[i][j].bg.x +38;
			S.T[i][j].hd.y = S.T[i][j].bg.y -38;
		}
		j = fgetc(F);	//retour à la ligne dans le fichier texte
	}
	fclose(F);
	S.jeu = NULL;
	return S;
}

SUDOKU ecrire_fichier(SUDOKU S) {
	int i,j;
	char nom[200];
	FILE *F = NULL;
	sprintf(nom,"%s.%04d.%s",S.fichier,++S.version,S.extension);
	F = fopen(nom,"w");
	for(i=0;i<VALEUR;i++){
		for(j=0;j<VALEUR;j++){
			if(S.T[i][j].val == 0) fputc('.',F);
				else{
						if(S.T[i][j].tra == 1) fputc('*',F);
						fputc((S.T[i][j].val +ASCII_0),F);
				}
		}
	fputc('\n',F);
	}
	fclose(F);
	return S;
}
