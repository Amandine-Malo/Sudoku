#include "gestion_sudoku.h"

#ifndef __AFFICHER_H
#define __AFFICHER_H

// Fonction a appeler au début poour créer la fenêtre graphique
void initialiser_fenetre_graphique();

// Fonction a appeler à la fin poour terminer proprement la fenêtre graphique
void terminer_fenetre_graphique();

// Fonction qui affiche le titre du fichier
void afficher_titre(SUDOKU S);

// Fonction qui affiche les chiffres
SUDOKU sudoku_chiffre_afficher(SUDOKU S);

// Fonction qui affiche la grille
SUDOKU sudoku_afficher(SUDOKU S);

// Fonction qui affiche le message msg
void affiche_message(char *msg);

#endif
