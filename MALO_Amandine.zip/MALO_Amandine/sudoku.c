#include <stdlib.h>
#include <uvsqgraphics.h>
#include "constantes.h"
#include "afficher.h"
#include "gestion_sudoku.h"
#include "lire_ecrire.h"

SUDOKU jouer(SUDOKU S) {
	POINT P;
	char touche;
	int fleche,r;
	r = wait_key_arrow_clic(&touche,&fleche,&P);
	
	if(r == EST_TOUCHE){
		switch(touche){
			case 'U' : 
				S = undo(S);
				return S;
				break;
				
			case 'V' :
				S = resolution(S,0);
				if(S.quit!=1) affiche_message("Pas de solutions");
				return S;
				break;
				
			case 'S' : 
				S = ecrire_fichier(S);
				affiche_message("Sauvegarde effectu"eacute"e");
				return S;
				break;
				
			case 'Q' :
				S.quit = 1;
				return S;
				break;
			
			default : 
				return S; 
				break;
		}		
	}
	
	if(r == EST_CLIC){	
		int ligne = (VALEUR - (P.y / TAILLE_CASE))-1; 
		int colonne = P.x / TAILLE_CASE;
		if(S.T[ligne][colonne].tra != 0)	//Test si case de travail ou non
			S = sudoku_modifier_case(S,ligne,colonne);
	}
	
	return S;
}

int main (int argc, char *argv[]) {
	SUDOKU S;
    S = lire_fichier(argv[1]);	// Pas de S, lire fichier crée la grille et la renvoie
    initialiser_fenetre_graphique();
    S = sudoku_afficher(S);
    S.quit = 0;
    while((S.fin != (VALEUR*VALEUR)) && (S.quit !=1)){
		S = jouer(S);
		affiche_all();
	}
	if(S.fin == VALEUR*VALEUR) affiche_message("GAGN"Eacute"");
    terminer_fenetre_graphique();
    exit(0);
}
