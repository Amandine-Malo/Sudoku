#include <stdio.h>
#include <uvsqgraphics.h>
#include "constantes.h"
#include "gestion_sudoku.h"

void initialiser_fenetre_graphique() {
	init_graphics(LARGEUR,HAUTEUR);
	fill_screen(COUL_FOND);
	affiche_auto_off();
}

void terminer_fenetre_graphique() {
	wait_escape();
}

void afficher_titre(SUDOKU S){
	char nom[200];
	POINT p;
	//sprintf : écrit dans une chaine de caractère
	//04d : affiche 4 décimal et met un 0 à la place de l'espace
	sprintf(nom,"%s.%04d.%s",S.fichier,S.version,S.extension);
	p.x = 0; p.y = HAUTEUR;
	aff_pol(nom,TAILLE_POLICE/2,p,COUL_TITRE);
}

SUDOKU sudoku_chiffre_afficher(SUDOKU S) {
	int i,j,a;
	POINT c;
	for(i=0,a=0;i<VALEUR;i++){
		for(j=0;j<VALEUR;j++){

			c.x = TAILLE_CASE*j+12;	c.y = HAUTEUR -(TAILLE_CASE*(i+1));
					
			if(S.T[i][j].val == 0){
				if(val_possible(S,i,j,S.T[i][j].val) == 0)	// Si prochaine valeur possible est 0 : aucune valeur possible
					draw_fill_rectangle(S.T[i][j].bg,S.T[i][j].hd,COUL_FOND_PB);
			}
			else{
				if(val_utilise(S,i,j,S.T[i][j].val)) 	// Si valeur utilisée plus d'une fois dans une ligne/colonne/carré
					draw_fill_rectangle(S.T[i][j].bg,S.T[i][j].hd,COUL_FOND_PB);
				else a++; // Si pas de problème
				
				if(!(S.T[i][j].tra)) aff_int(S.T[i][j].val,TAILLE_POLICE,c,COUL_VAL_DEPART); // Variable de départ
				else{
					if(S.quit == 1)	// Résolution
					aff_int(S.T[i][j].val,TAILLE_POLICE,c,COUL_VAL_SOLVE);
			
					else if(S.T[i][j].tra)	// Variable travail
					aff_int(S.T[i][j].val,TAILLE_POLICE,c,COUL_VAL_TRAVAIL);
				}
			}
		}
	}
	
	S.fin = a;
	return S;
}

SUDOKU sudoku_afficher(SUDOKU S){
	POINT p1,p2,p3,p4,p5,p6;
	int i;
	fill_screen(COUL_FOND);
	for(i=0;i<=VALEUR;i++){
		//Quadrillage
		p1.x = TAILLE_CASE*i;	p1.y = 0;
		p2.x = TAILLE_CASE*i;	p2.y = HAUTEUR-TAILLE_CASE;
		p3.x = 0;				p3.y = TAILLE_CASE*i;
		p4.x = LARGEUR; 		p4.y = TAILLE_CASE*i;
		
		if(i%3 == 0){
			p5.x = p1.x -1; p5.y = p1.y;
			p6.x = p2.x +1; p6.y = p2.y;
			draw_fill_rectangle(p5,p6,COUL_TRAIT);
			p5.x = p3.x; p5.y = p3.y-1;
			p6.x = p4.x; p6.y = p4.y +1;
			draw_fill_rectangle(p5,p6,COUL_TRAIT);
		}
			else{
				draw_line(p1,p2,COUL_TRAIT);
				draw_line(p3,p4,COUL_TRAIT);
			}	
	}
	S = sudoku_chiffre_afficher(S);
	afficher_titre(S);
	affiche_all();
	return S;
}

void affiche_message(char *msg){
	POINT p,f;
	p.x = 0; p.y = HAUTEUR - 20;
	f.x = LARGEUR; f.y = HAUTEUR -38;
	draw_fill_rectangle(p,f,COUL_FOND);
	aff_pol(msg,TAILLE_POLICE/2,p,COUL_MESSAGE);
}
