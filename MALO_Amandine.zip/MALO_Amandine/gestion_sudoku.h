#ifndef __SUDOKU_H
#define __SUDOKU_H

struct action{				//Pile dynamique
	int l,c;				//ligne,colonnes
	int a;					//ancienne et nouvelle valeur
	struct action *prec;	//Pointe sur une action précedente
};
typedef struct action ACTION;

struct s_case{
	POINT bg,hd;
	int val;
	int tra;	//Variable de travail : indique si case de travail ou non
};
typedef struct s_case S_CASE;

struct sudoku {
	S_CASE T[VALEUR][VALEUR];	//Tableau de 9*9
	char fichier[50];			//Nom du fichier
	char extension[50]; 		//.sudoku
	int version;				//version du fichier (sauvegardes)
	ACTION *jeu;				//Suivis des actions
	int fin;
	int quit;
};
typedef struct sudoku SUDOKU;


// Annule la dernière action
SUDOKU undo(SUDOKU S);

// Vérifie si la valeur est utilisée dans la ligne
int val_utilise_h(SUDOKU S, int l, int c, int v);

// Vérifie si la valeur est utilisée dans la colonne
int val_utilise_v(SUDOKU S, int l, int c, int v);

// Vérifie si la valeur est utilisée dans le carrée 3*3
int val_utilise_c(SUDOKU S, int l, int c, int v);

// Variable utilisée = 1, et non utilisée = 0
int val_utilise(SUDOKU S, int l, int c, int v);

// Valeur possible si non utilisé
int val_possible(SUDOKU S, int l, int c, int v);

// Modifie la valeur de la case
SUDOKU sudoku_modifier_case(SUDOKU S, int l, int c);

// Résolution du sudoku
SUDOKU resolution(SUDOKU S, int val);

#endif
